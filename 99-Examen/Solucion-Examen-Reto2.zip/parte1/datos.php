<?php
// Diccionario de usuarios:
$usuarios = [
    "jvadillo" => [
        "id" => 1,
        "nombre" => "Jon",
        "apellidos" => "Vadillo Romero",
        "email" => "jvadillo@egibide.org",
        "contrasena" => "1234"
    ],
    "iperez" => [
        "id" => 2,
        "nombre" => "Imanol",
        "apellidos" => "Perez Fernandez",
        "email" => "iperez@egibide.org",
        "contrasena" => "1234"
    ]
];