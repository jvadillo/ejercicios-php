<?php require_once "partials/header.php"; ?>

    <h1>Login</h1>
    <p>Introduce un usuario y contraseña válidos (e.g.: jvadillo / 1234)</p>
    <form action="#" method="post">
        <input type="text" name="usuario">
        <input type="password" name="contrasena">
        <input type="submit" name="login" value="Entrar">
    </form>

<?php require_once "partials/footer.php"; ?>
