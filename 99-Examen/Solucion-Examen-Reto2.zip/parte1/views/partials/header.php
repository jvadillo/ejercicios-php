<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Examen 1</title>
    <style>
        body {
            margin: 20px;
        }
        h4 {
            margin-bottom: 22px;
        }
        .table {
            width: 600px;
        }
    </style>
</head>
<body>