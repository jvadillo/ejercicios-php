<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Examen 1</title>
    <style>
        body {
            margin: 20px;
        }
        h4 {
            margin-bottom: 22px;
        }
        .table {
            width: 600px;
        }
    </style>
</head>
<body>

    <h1>Login</h1>
    <p>Introduce un usuario y contraseña válidos (e.g.: jvadillo / 1234)</p>
    <form action="#" method="post">
        <input type="text" name="usuario">
        <input type="password" name="contrasena">
        <input type="submit" name="login" value="Entrar">
    </form>

</body>

</html>