<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Examen 1</title>
    <style>
        body {
            margin: 20px;
        }
        h4 {
            margin-bottom: 22px;
        }
        .table {
            width: 600px;
        }
    </style>
</head>
<body>

<h1>Lista de tareas</h1>
<p>Usuario contectado <b><?php echo $_SESSION["usuario"] ?></b>.</p>
<h2>Añadir nueva</h2>
<form action="index.php" method="GET">
    <label>Descripcion: </label>
    <input type="text" name="codigo">
    <input type="text" name="nombre">
    <input type="text" name="apellidos">
    <input type="hidden" name="accion" value="nuevo">
    <input type="submit" value="Añadir!">
</form>
<h2>Listado de pacientes</h2>
<p>Si el valor entre paréntesis es 0, significa que el paciente no está atendido.</p>
<table class="table">
    <?php
    foreach ($_SESSION['pacientes'] as $paciente)
    {
        ?>
        <tr>
            <td><?php echo $paciente['nombre'] . '  (' . $paciente['atendido'] . ')' ?></td>
            <td><a href="index.php?accion=marcar&codigo=<?php echo $paciente['codigo'] ?>">Marcar atendido</a></td>
            <td><a href="index.php?accion=borrar&codigo=<?php echo $paciente['codigo'] ?>">Borrar</a></td>
        </tr>
        <?php
    }
    ?>
</table>

</body>

</html>