<!doctype html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<div>
    <h1>Ejercicio 5 (layouts)</h1>
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html>
<?php /**PATH /vagrant/07-Template-Egines/ejercicio5/views/layouts/app.blade.php ENDPATH**/ ?>