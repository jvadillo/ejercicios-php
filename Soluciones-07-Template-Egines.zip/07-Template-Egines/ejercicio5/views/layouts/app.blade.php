<!doctype html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<div>
    <h1>Ejercicio 5 (layouts)</h1>
    @yield('content')
</div>
</body>
</html>
