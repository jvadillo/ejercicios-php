<!doctype html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <h1>Ejercicio 6 (layouts)</h1>
    <h2>Página actual: {{ $paginaActual }}</h2>
    @yield('content')
</body>
</html>
