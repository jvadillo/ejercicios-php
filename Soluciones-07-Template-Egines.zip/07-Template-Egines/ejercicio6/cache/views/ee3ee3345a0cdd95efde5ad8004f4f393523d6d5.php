<!doctype html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <h1>Ejercicio 6 (layouts)</h1>
    <h2>Página actual: <?php echo e($paginaActual); ?></h2>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH /vagrant/07-Template-Egines/ejercicio6/views/layouts/app.blade.php ENDPATH**/ ?>