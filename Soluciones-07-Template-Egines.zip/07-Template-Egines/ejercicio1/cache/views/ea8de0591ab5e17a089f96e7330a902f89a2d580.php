<!doctype html>
<html>
<head>
    <title>Ejercicio 1</title>
    <meta charset="utf-8">
</head>
<body>
    <h1>Bienvenido, <?php echo e($nombre); ?></h1>
</body>
</html>
<?php /**PATH /vagrant/07-Template-Egines/ejercicio1/views/welcome.blade.php ENDPATH**/ ?>