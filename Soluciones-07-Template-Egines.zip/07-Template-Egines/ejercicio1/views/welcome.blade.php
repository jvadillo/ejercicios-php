<!doctype html>
<html>
<head>
    <title>Ejercicio 1</title>
    <meta charset="utf-8">
</head>
<body>
    <h1>Bienvenido, {{ $nombre }}</h1>
</body>
</html>
