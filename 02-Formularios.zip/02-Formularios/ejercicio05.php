<?php
/*** DATOS ***/
require 'ejercicio05-datos.php';

// Cargar la vista
require 'ejercicio05index.view.php';