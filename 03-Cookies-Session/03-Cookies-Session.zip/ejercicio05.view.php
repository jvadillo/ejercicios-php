<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ejercicios PHP</title>
</head>
<body>
<h1>Soluciones de ejercicios PHP</h1>

<p>Bienvenid@, <?= $nombre ?> <?= $apellidos ?></p>
<a href='ejercicio05.php?accion=cerrar'>Cerrar sesión</a>

</body>
</html>