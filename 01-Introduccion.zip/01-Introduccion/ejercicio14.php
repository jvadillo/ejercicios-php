<?php

$diccionario = [
    "casa" => "house",
    "gato" => "cat",
    "perro" => "dog",
    "colegio" => "school",
    "pais" => "country"
];

require "ejercicio14.view.php";