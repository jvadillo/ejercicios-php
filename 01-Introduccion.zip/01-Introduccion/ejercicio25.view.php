<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ejercicios PHP</title>
</head>
<body>
<h1>Soluciones de ejercicios PHP</h1>
<h2>Tema 1: Introducción a PHP</h2>
<h3>Ejercicio 25</h3>
<h4>Enunciado:</h4>
<p>
    25. Crea un array con un listado de estudiantes (Ane, Markel, Nora, Danel, Amaia, Izaro). A continuación recorre el array utilizando una estructura de control WHILE generando una lista HTML como la siguiente:
</p>
<h4>Solución:</h4>

<?= generarListado($estudiantes) ?>

</body>
</html>