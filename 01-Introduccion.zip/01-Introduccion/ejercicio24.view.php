<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ejercicios PHP</title>
</head>
<body>
<h1>Soluciones de ejercicios PHP</h1>
<h2>Tema 1: Introducción a PHP</h2>
<h3>Ejercicio 24</h3>
<h4>Enunciado:</h4>
<p>
    24. Crea un array con un listado de estudiantes (Ane, Markel, Nora, Danel, Amaia, Izaro). A continuación recorre el array generando una lista HTML como la siguiente:
</p>
<h4>Solución:</h4>

<?= generarTabla($agenda) ?>

</body>
</html>