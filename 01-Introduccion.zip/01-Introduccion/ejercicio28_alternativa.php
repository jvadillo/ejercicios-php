<?php

$marcas = ["Audi", "Seat", "Mercedes", "Volskwagen", "BMW", "Fiat"];

require "ejercicio28_alternativa.view.php";